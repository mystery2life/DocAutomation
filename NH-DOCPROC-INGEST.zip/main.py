import os, base64, datetime as dt, json, logging, hashlib
from typing import Optional

from fastapi import FastAPI, HTTPException, Header, Request
from pydantic import BaseModel, Field, constr

# Azure SDKs
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient, ContentSettings
from azure.servicebus import ServiceBusClient, ServiceBusMessage
import pyodbc



# ---------------------------
# Settings / Environment
# ---------------------------
APP_NAME = "DocProc Ingestion API"
API_KEY = os.getenv("INGRESS_API_KEY")  # dev-only gate while OAuth is off

STORAGE_ACCOUNT_URL = os.getenv("STORAGE_ACCOUNT_URL")            # preferred (Managed Identity)
STORAGE_CONNECTION_STRING = os.getenv("STORAGE_CONNECTION_STRING")# dev fallback
STORAGE_CONTAINER = os.getenv("STORAGE_CONTAINER", "ingest")

SB_NAMESPACE = os.getenv("SERVICEBUS_NAMESPACE")                   # preferred (Managed Identity)
SB_CONNECTION_STRING = os.getenv("SB_CONNECTION_STRING")           # dev fallback
SB_QUEUE_CLASSIFY = os.getenv("SERVICEBUS_QUEUE_CLASSIFY", "q-classify")

SQL_SERVER = os.getenv("SQL_SERVER")
SQL_DB = os.getenv("SQL_DB")
SQL_AUTH = os.getenv("SQL_AUTH", "SqlPassword")  # SqlPassword | ManagedIdentity
SQL_USER = os.getenv("SQL_USER")
SQL_PASSWORD = os.getenv("SQL_PASSWORD")
SQL_SCHEMA = os.getenv("SQL_SCHEMA", "DocMeta")
SQL_TABLE = os.getenv("SQL_TABLE", "IngestMeta")

MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))

# ---------------------------
# Logging
# ---------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(APP_NAME)

# ---------------------------
# Azure Credentials (works for MI; harmless in dev)
# ---------------------------
cred = DefaultAzureCredential(exclude_environment_credential=False)

# ---------------------------
# Blob client (MI first, else connection string)
# ---------------------------
if STORAGE_ACCOUNT_URL:
    blob_service = BlobServiceClient(account_url=STORAGE_ACCOUNT_URL, credential=cred)
else:
    if not STORAGE_CONNECTION_STRING:
        raise RuntimeError("No storage credentials configured.")
    blob_service = BlobServiceClient.from_connection_string(STORAGE_CONNECTION_STRING)
ingest_container = blob_service.get_container_client(STORAGE_CONTAINER)

# ---------------------------
# Service Bus client (MI first, else connection string)
# ---------------------------
if SB_NAMESPACE:
    sb_client = ServiceBusClient(SB_NAMESPACE, credential=cred, logging_enable=False)
else:
    if not SB_CONNECTION_STRING:
        raise RuntimeError("No Service Bus credentials configured.")
    sb_client = ServiceBusClient.from_connection_string(SB_CONNECTION_STRING, logging_enable=False)

# ---------------------------
# SQL helpers
# ---------------------------
ODBC_BASE = (
    "Driver={{ODBC Driver 18 for SQL Server}};"
    "Server=tcp:{server},1433;"
    "Database={db};"
    "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
).format(server=SQL_SERVER, db=SQL_DB)

def sql_connect():
    """Return a pyodbc connection using Managed Identity or SQL password."""
    if SQL_AUTH.lower() == "managedidentity":
        token = cred.get_token("https://database.windows.net/.default").token
        access_token = bytes(token, "utf-16-le")  # Microsoft extension
        return pyodbc.connect(ODBC_BASE, attrs_before={1256: access_token})  # 1256=SQL_COPT_SS_ACCESS_TOKEN
    elif SQL_AUTH.lower() == "sqlpassword":
        if not (SQL_USER and SQL_PASSWORD):
            raise RuntimeError("SQL_USER/SQL_PASSWORD required for SqlPassword mode.")
        return pyodbc.connect(ODBC_BASE + f"Uid={SQL_USER};Pwd={SQL_PASSWORD};")
    else:
        raise RuntimeError("SQL_AUTH must be ManagedIdentity or SqlPassword")

# ---------------------------
# Request model & validation
# ---------------------------
class IngestRequest(BaseModel):
    rid_number: constr(strip_whitespace=True, min_length=1, max_length=64) = Field(alias="rid_number")
    document_id: constr(strip_whitespace=True, min_length=1, max_length=64) = Field(alias="document_id")
    filename: constr(strip_whitespace=True, min_length=1, max_length=256)
    doc_type: Optional[constr(strip_whitespace=True, max_length=32)] = "UNKNOWN"
    no_of_pages: Optional[int] = None
    content_b64: str  # base64-encoded PDF

    class Config:
        populate_by_name = True

# ---------------------------
# App
# ---------------------------
app = FastAPI(title=APP_NAME)

@app.get("/health")
def health():
    return {"ok": True, "service": APP_NAME}

def _bytes_from_b64(b64: str) -> bytes:
    """Decode base64 to bytes; enforce size and basic PDF sanity."""
    try:
        data = base64.b64decode(b64, validate=True)
    except Exception:
        raise HTTPException(status_code=400, detail="content_b64 is not valid base64")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File too large. Max {MAX_UPLOAD_MB} MB")
    if not data.startswith(b"%PDF"):
        log.warning("Uploaded content does not start with %%PDF header; proceeding.")
    return data

def _store_blob(r: IngestRequest, pdf_bytes: bytes) -> str:
    """Write PDF to Blob at a consistent path; return blob_path."""
    now = dt.datetime.utcnow()
    blob_path = f"ingest/{now:%Y/%m/%d}/{r.rid_number}/{r.document_id}.pdf"
    sha256 = hashlib.sha256(pdf_bytes).hexdigest()

    ingest_container.upload_blob(
        name=blob_path,
        data=pdf_bytes,
        overwrite=True,
        metadata={
            "rid": r.rid_number,
            "document_id": r.document_id,
            "doc_type": r.doc_type or "UNKNOWN",
            "no_of_pages": str(r.no_of_pages or ""),
            "sha256": sha256,
        },
        content_settings=ContentSettings(content_type="application/pdf"),
    )
    return blob_path

def _ensure_table(cur):
    """Create schema/table once (safe to run repeatedly)."""
    cur.execute(f"""
    IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = '{SQL_SCHEMA}')
        EXEC('CREATE SCHEMA {SQL_SCHEMA}');
    IF OBJECT_ID('{SQL_SCHEMA}.{SQL_TABLE}') IS NULL
        EXEC('CREATE TABLE {SQL_SCHEMA}.{SQL_TABLE} (
            IngestId UNIQUEIDENTIFIER DEFAULT NEWID() PRIMARY KEY,
            DocumentId NVARCHAR(64) NOT NULL,
            RID_Number NVARCHAR(64) NOT NULL,
            DocType NVARCHAR(32) NOT NULL,
            NoOfPages INT NULL,
            BlobPath NVARCHAR(512) NOT NULL,
            SubmittedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
            CONSTRAINT UQ_RID_Doc UNIQUE (RID_Number, DocumentId)
        )');
    """)

def _insert_sql(r: IngestRequest, blob_path: str) -> None:
    """Insert one tracking row; ignore duplicate (same RID_Number + DocumentId)."""
    with sql_connect() as conn:
        cur = conn.cursor()
        _ensure_table(cur)
        try:
            cur.execute(f"""
                INSERT INTO {SQL_SCHEMA}.{SQL_TABLE}
                    (DocumentId, RID_Number, DocType, NoOfPages, BlobPath)
                VALUES (?, ?, ?, ?, ?)
            """, (r.document_id, r.rid_number, r.doc_type or "UNKNOWN", r.no_of_pages, blob_path))
            conn.commit()
        except pyodbc.Error as e:
            # 2627 unique constraint violation
            if "2627" in str(e):
                log.info("Duplicate record for RID=%s, DocumentId=%s; continuing.", r.rid_number, r.document_id)
            else:
                raise

def _enqueue_sb(r: IngestRequest, blob_path: str) -> None:
    """Send a work message to Service Bus for the Classifier."""
    payload = {
        "rid": r.rid_number,
        "document_id": r.document_id,
        "doc_type": r.doc_type or "UNKNOWN",
        "no_of_pages": r.no_of_pages,
        "blob_path": blob_path,
        "status": "INGESTED",
        "submitted_at": dt.datetime.utcnow().isoformat() + "Z",
    }
    body = json.dumps(payload)
    with sb_client:
        sender = sb_client.get_queue_sender(queue_name=SB_QUEUE_CLASSIFY)
        with sender:
            sender.send_messages(ServiceBusMessage(
                body, content_type="application/json",
                subject="classify", correlation_id=r.rid_number
            ))

@app.post("/ingest")
def ingest(req: IngestRequest, request: Request, x_api_key: Optional[str] = Header(default=None)):
    """
    Main endpoint:
      1) (Dev) Guard with X-Api-Key while OAuth is off.
      2) Decode base64 -> bytes
      3) Store PDF in Blob
      4) Insert SQL row
      5) Enqueue Service Bus message
    """
    # Dev-only guard (remove once OAuth is enabled)
    if API_KEY:
        if not x_api_key or x_api_key != API_KEY:
            raise HTTPException(status_code=401, detail="Unauthorized")

    pdf_bytes = _bytes_from_b64(req.content_b64)
    blob_path = _store_blob(req, pdf_bytes)
    _insert_sql(req, blob_path)
    _enqueue_sb(req, blob_path)

    logging.info("INGESTED rid=%s doc=%s path=%s", req.rid_number, req.document_id, blob_path)
    return {"status": "INGESTED", "rid": req.rid_number, "blob_path": blob_path}
